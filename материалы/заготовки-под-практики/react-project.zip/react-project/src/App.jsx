export default function App() {

  return (
    <div className='ViteApp'>
      <h1>Новый проект React</h1>
    </div>
  )
}
